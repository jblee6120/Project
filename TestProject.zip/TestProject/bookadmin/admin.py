from django.contrib import admin
from .models import Sciencebook, Philosophybook
# Register your models here.
admin.site.register(Sciencebook)
admin.site.register(Philosophybook)