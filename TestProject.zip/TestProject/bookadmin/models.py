from django.db import models
# Create your models here.
# 책의 DB모델 추후에 MySQL로 변경하여 다시 만들어야 함.
# 책 주제별로 DB를 관리하는 것 보다는 전체 책을 담는 DB를 사용하는 것이 검색에 용이해 보임
class Sciencebook(models.Model):
    class Meta:
        db_table = "sciencebook"

    def __str__(self):
        return self.title

    title = models.CharField(max_length=256, null=False)
    barcode = models.CharField(max_length=64, null=True)
    author = models.CharField(max_length=64, null=False)
    borrowed_date = models.DateTimeField(auto_now_add=True)
    book_in_here = models.BooleanField(default=True)
    location = models.CharField(max_length=20)

class Philosophybook(models.Model):
    class Meta:
        db_table = "philosophybook"

    def __str__(self):
        return self.title

    title = models.CharField(max_length=256, null=False)
    barcode = models.CharField(max_length=64, null=True)
    author = models.CharField(max_length=64, null=False)
    borrowed_date = models.DateTimeField(auto_now_add=True)
    book_in_here = models.BooleanField(default=True)
    location = models.CharField(max_length=20)