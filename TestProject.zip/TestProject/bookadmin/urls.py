from django.shortcuts import render, redirect
from django.urls import path
from . import views
urlpatterns = [
    path("findbook/", views.user_find_book, name="find-book"),
    path("managebook/", views.manager_manage_book, name="manage-book"),
    path("managebook/search/", views.search, name="search"),
]