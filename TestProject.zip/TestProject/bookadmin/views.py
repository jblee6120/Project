from django.shortcuts import render, redirect
from .models import Sciencebook, Philosophybook
from django.http import HttpResponse
# Create your views here.
# 책을 관리하는 앱의 view파일
def user_find_book(request):
    if request.method == 'GET':
        return render(request, 'bookadmin/userfindbook.html')

    elif request.method == 'POST':
        title1 = request.POST.get('title1', None)
        title2 = request.POST.get('title2', None)
        title3 = request.POST.get('title3', None)
        title4 = request.POST.get('title4', None)

        findbook1 = Sciencebook.objects.filter(title=title1)
        findbook2 = Sciencebook.objects.filter(title=title2)
        findbook3 = Sciencebook.objects.filter(title=title3)
        findbook4 = Sciencebook.objects.filter(title=title4)

        if findbook1:
            return render(request, 'bookadmin/booklist.html',
                          {'findbook1':findbook1,
                          'findbook2': findbook2,
                          'findbook3': findbook3,
                          'findbook4': findbook4})
        else:
            return render(request, 'bookadmin/userfindbook.html')

def manager_manage_book(request):
    if request.method == 'GET':
        return render(request, 'bookadmin/managermanagebook.html')

    elif request.method == 'POST':
        book = [None] * 5
        barcode = [None] * 5
        for i in range(5):
            barcode[i] = request.POST.get('barcode{}'.format(i), None)
            book[i] = Sciencebook.objects.filter(barcode=barcode[i])

        if book[0]:
            return render(request, 'bookadmin/search.html', {'book0': book[0],
                                                             'book1': book[1],
                                                             'book2': book[2],
                                                             'book3': book[3],
                                                             'book4': book[4]})
        else:
            return render(request, 'bookadmin/managermanagebook.html')

def search(request):
    if request.method == 'POST':
        book = request.POST.get("book", None)
        rebook = Sciencebook.objects.get(title=book)


        return render(request, 'bookadmin/search.html', {'rebook': rebook})
    else:
        return render(request, 'bookadmin/search.html')