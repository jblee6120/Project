from django.shortcuts import render, redirect
# Create your views here.
# 초기화면을 띄우는 앱의 views파일
def sheet(request):
    if request.method == 'GET':
        return render(request, 'common/base.html')