from django.db import models

# Create your models here.

class Usermodel(models.Model):
    username = models.CharField(max_length=20, null=False)
    password = models.CharField(max_length=20, null=False)
    is_manager = models.BooleanField(default=True)
