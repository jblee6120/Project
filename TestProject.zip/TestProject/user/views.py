from django.shortcuts import render, redirect
from . models import Usermodel
from django.http import HttpResponse

# Create your views here.

def sign_up_view(request):
    if request.method == 'GET':
        return render(request, 'user/signup.html')

    elif request.method == 'POST':
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        password2 = request.POST.get('password2', None)
        is_manager = request.POST.get('is_manager', None)

        if password != password2:
            render(request, 'user/signup.html')

        else:
            check = Usermodel.objects.filter(username=username)
            if check:
                return render(request, 'user/signup.html')
            else:
                Usermodel.objects.create(username=username, password=password, is_manager=is_manager)
                return render(request, 'user/signin.html')


def sign_in_view(request):
    if request.method == 'GET':
        return render(request, 'user/signin.html')

    elif request.method == 'POST':
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        me = Usermodel.objects.get(username=username)

        if me.password == password:
            request.session['user'] = me.username
            return HttpResponse('login success!')

        else:
            return render(request, 'user/signin.html')


